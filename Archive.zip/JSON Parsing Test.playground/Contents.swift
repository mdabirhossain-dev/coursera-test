import UIKit

struct Result: Codable {
    
    let gender: String
    let email: String
}

let url = URL(string: "https://randomuser.me/api/?results=10")!

URLSession.shared.dataTask(with: url) { data, _, _ in
    if let data = data {

        let results = try? JSONDecoder().decode([Result].self, from: data)
        print(results![0])
    }
}.resume()
