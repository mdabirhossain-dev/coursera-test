//
//  ViewController.swift
//  Api Call (Test)
//
//  Created by AM1 on 18/5/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

