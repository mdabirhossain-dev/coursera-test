//
//  JSON.swift
//  Api Call (Test)
//
//  Created by AM1 on 19/5/22.
//

import UIKit

let url = URL(string: "https://randomuser.me/api/?results=10")!

URLSession.shared.dataTask(with: url) { data, _, _ in
    if let data = data {
        print(data)
    }
}.resume()
