//
//  UserViewModel.swift
//  Api Call
//
//  Created by AM1 on 18/5/22.
//

import UIKit

class UserViewModel{
    
    weak var vc: ViewController?
    var arrUser = [Json4Swift_Base]()
    var arrLoccation = [Location]()
    //    var arrName = [Name]()
    
    func getAllUserJson4Swift_Base() {
        URLSession.shared.dataTask(with: URL(string: "https://jsonplaceholder.typicode.com/todos")!) { (data, response, error) in
            if error == nil {
                if let data = data {
                    do{
                        let userResponse = try JSONDecoder().decode([Json4Swift_Base].self, from: data)
                        print(self.arrUser)
                    }catch let err{
                        print(err.localizedDescription)
                    }
                }
            }else{
                print(error?.localizedDescription)
            }
        }.resume()
    }
    func getAllUserLocation() {
        URLSession.shared.dataTask(with: URL(string: "https://randomuser.me/api/?results=10")!) { (data, response, error) in
            if error == nil {
                if let data = data {
                    do{
                        let userResponse = try JSONDecoder().decode([Location].self, from: data)
                        print(self.arrLoccation)
                    }catch let err{
                        print(err.localizedDescription)
                    }
                }
            }else{
                print(error?.localizedDescription)
            }
        }.resume()
    }
}
