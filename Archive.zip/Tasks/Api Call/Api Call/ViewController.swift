//
//  ViewController.swift
//  Api Call
//
//  Created by AM1 on 17/5/22.
//

import UIKit

class ViewController: UIViewController {

    var viewModelUser = UserViewModel()
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModelUser.getAllUserJson4Swift_Base()
        viewModelUser.getAllUserLocation()
//        viewModelUser.getAllUserName()
        // Do any additional setup after loading the view.
    }


}

