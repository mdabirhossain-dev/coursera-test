//
//  Fetch.swift
//  Api Call
//
//  Created by AM1 on 17/5/22.
//

import UIKit

class Fetch: NSObject {

}
